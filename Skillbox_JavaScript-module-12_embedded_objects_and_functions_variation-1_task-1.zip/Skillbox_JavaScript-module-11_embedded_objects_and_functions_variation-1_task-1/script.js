window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    document.querySelector(".wrapper").classList.add("visible");
  }, 3000);
});

document.addEventListener("DOMContentLoaded", () => {
  const giftArr = [
    {
      title: "Скидка 20% на первую покупку в нашем магазине!",
      icon: "gift",
      // icon: "/discount.svg",
    },
    {
      title: "Подарок при первой покупке в нашем магазине!",
      icon: "delivery",
      // icon: "/gift.svg",
    },
    {
      title: "Бесплатная доставка для вас!",
      icon: "discount",
      // icon: "/delivery.svg",
    },
    {
      title: "Сегодня день больших скидок!",
      icon: "discountbig",
      // icon: "/discountbig.svg",
    },
  ];

  const randomGift = giftArr[Math.floor(Math.random() * giftArr.length)];

  // Находим элементы
  const titleEl = document.querySelector(".title");
  const iconEl = document.querySelector("svg.icon use");
  const buttonEl = document.querySelector(".button");
  const wrapperEl = document.querySelector(".wrapper");

  // Обновляем содержимое
  if (titleEl) titleEl.textContent = randomGift.title;
  if (iconEl)
    iconEl.setAttribute("xlink:href", `./images/sprite.svg#${randomGift.icon}`);

  // Показываем карточку
  if (wrapperEl) {
    wrapperEl.classList.add("visible");
  }

  if (buttonEl && wrapperEl) {
    buttonEl.addEventListener("click", () => {
      wrapperEl.style.opacity = "0";
      setTimeout(() => wrapperEl.remove(), 500);
    });
  }
});
