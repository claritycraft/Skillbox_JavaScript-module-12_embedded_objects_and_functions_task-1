window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    document.querySelector(".wrapper").classList.add("visible");
  }, 3000);
});

document.addEventListener("DOMContentLoaded", () => {
  const giftArr = [
    {
      title: "Скидка 20% на первую покупку в нашем магазине!",
      // тут указываем id svg из спрайта
      icon: "gift",
      // icon: "/discount.svg",
    },
    {
      title: "Подарок при первой покупке в нашем магазине!",
      // тут указываем id svg из спрайта
      icon: "delivery",
      // icon: "/gift.svg",
    },
    {
      title: "Бесплатная доставка для вас!",
      // тут указываем id svg из спрайта
      icon: "discount",
      // icon: "/delivery.svg",
    },
    {
      title: "Сегодня день больших скидок!",
      // тут указываем id svg из спрайта
      icon: "discountbig",
      // icon: "/discountbig.svg",
    },
  ];

  const randomGift = giftArr[Math.floor(Math.random() * giftArr.length)];
  const titleEl = document.querySelector(".title");
  const iconEl = document.querySelector("svg.icon use");

  if (titleEl) {
    titleEl.textContent = randomGift.title;
  }
  if (iconEl)
    iconEl.setAttribute("xlink:href", `images/sprite.svg#${randomGift.icon}`);
});

document.addEventListener("DOMContentLoaded", function () {
  const divEL = document.querySelector(".wrapper");
  const buttonEl = document.querySelector(".button");
  if (divEL && buttonEl) {
    buttonEl.addEventListener("click", function () {
      divEL.remove();
    });
  }
});
